//
//  CountryAndCityWeatherDisplayCustomTableViewCell.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 13..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class CountryAndCityWeatherDisplayCustomTableViewCell: UITableViewCell {
    
    @IBOutlet var cityNameLabel : UILabel!
    @IBOutlet var celsiusAndFahrenheightLabel : UILabel!
    @IBOutlet var rainfallProbabilityLabel : UILabel!
    @IBOutlet var weatherStateImageView : UIImageView!
}

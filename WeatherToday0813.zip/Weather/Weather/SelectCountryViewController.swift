//
//  SelectCountryViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 12..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SelectCountryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView : UITableView!
    let defaultCellIdentifier : String = "cell"
    var country : [CountryInfo] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        self.navigationItem.title = "세계 날씨"
        
        let jsonDecoder = JSONDecoder()
        guard let dataAsset : NSDataAsset = NSDataAsset(name: "countries") else {
            return
        }
        do {
            self.country = try jsonDecoder.decode([CountryInfo].self, from: dataAsset.data)
        } catch {
            print (error.localizedDescription)
        }
        
        self.tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.country.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: self.defaultCellIdentifier, for: indexPath)
        
        let country : CountryInfo = self.country[indexPath.row]
        
        //var tag : Int = cell.tag
        
        cell.textLabel?.text = country.koreanName
        cell.imageView?.image = UIImage(named: country.flagOfCountry)
        cell.tag = indexPath.row
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell = tableView.cellForRow(at: indexPath)
        self.performSegue(withIdentifier: "showCountryWeatherView", sender: cell)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let nextViewController : CountryWeatherViewController = segue.destination as? CountryWeatherViewController else {
            return
        }
        guard let cell : UITableViewCell = sender as? UITableViewCell else {
            return
        }
        
        let tag : Int = cell.tag
        
        nextViewController.countries = self.country[tag]
        
    }
}

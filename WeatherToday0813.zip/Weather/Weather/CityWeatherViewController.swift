//
//  CityWeatherViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 12..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class CityWeatherViewController: UIViewController {
    
    var citiesWeather : WeatherInfo!
    @IBOutlet var weatherStateImageView : UIImageView!
    @IBOutlet var weatherStateLabel : UILabel!
    @IBOutlet var celsiusAndFahrenheightLabel : UILabel!
    @IBOutlet var rainfallProbabilityLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = citiesWeather.cityName
        
        weatherStateImageView.image = UIImage(named: citiesWeather.weatherImage)
        weatherStateLabel.text = citiesWeather.weatherState
        celsiusAndFahrenheightLabel.text = "섭씨 \(citiesWeather.celsius)도 /" + " 화씨 \(citiesWeather.fahrenheight)도"
        rainfallProbabilityLabel.text = "강수확률 \(citiesWeather.rainfallProbability)%"
        setLabelColor(weather: citiesWeather)
        
    }
    
    func setLabelColor(weather : WeatherInfo) {
        if weather.celsius >= 25.0 {
            celsiusAndFahrenheightLabel.textColor = UIColor.red
        } else if weather.celsius < 10.0 {
            celsiusAndFahrenheightLabel.textColor = UIColor.blue
        } else{
            celsiusAndFahrenheightLabel.textColor = UIColor.black
        }
        if weather.rainfallProbability > 50 {
            rainfallProbabilityLabel.textColor = UIColor.orange
        } else {
            rainfallProbabilityLabel.textColor = UIColor.black
        }
    }
    
}

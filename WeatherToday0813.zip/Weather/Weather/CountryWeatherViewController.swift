//
//  CountryWeatherViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 12..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class CountryWeatherViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView : UITableView!
    
    let defaultCellIdentifier : String = "customCell"
    var weather : [WeatherInfo] = []
    var countries : CountryInfo!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.delegate = self
        tableView.dataSource = self
        self.navigationItem.title = countries.koreanName
        
        let jsonDecoder = JSONDecoder()
        guard let dataAsset : NSDataAsset = NSDataAsset(name: countries.assetName) else {
            return
        }
        do {
            self.weather = try jsonDecoder.decode([WeatherInfo].self, from: dataAsset.data)
        } catch {
            print (error.localizedDescription)
        }
        
        self.tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.weather.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: self.defaultCellIdentifier, for: indexPath) as! CountryAndCityWeatherDisplayCustomTableViewCell
        
        let weather : WeatherInfo = self.weather[indexPath.row]
        
        
        cell.cityNameLabel.text = weather.cityName
        cell.celsiusAndFahrenheightLabel.text = "섭씨 \(weather.celsius)도 /" + " 화씨 \(weather.fahrenheight)도"
        cell.rainfallProbabilityLabel.text = "강수확률 \(weather.rainfallProbability)%"
        cell.weatherStateImageView.image = UIImage(named: weather.weatherImage)
        setCellLabelColor(weather: weather, cell: cell)
        
        cell.tag = indexPath.row
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell = tableView.cellForRow(at: indexPath)
        self.performSegue(withIdentifier: "showCityWeatherView", sender: cell)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let nextViewController : CityWeatherViewController = segue.destination as? CityWeatherViewController else {
            return
        }
        guard let cell : UITableViewCell = sender as? UITableViewCell else {
            return
        }
        
        let tag : Int = cell.tag
        
        nextViewController.citiesWeather = self.weather[tag]
        
    }
    
    func setCellLabelColor(weather : WeatherInfo, cell : CountryAndCityWeatherDisplayCustomTableViewCell) {
        if weather.celsius >= 25.0 {
            cell.celsiusAndFahrenheightLabel.textColor = UIColor.red
        } else if weather.celsius < 10.0 {
            cell.celsiusAndFahrenheightLabel.textColor = UIColor.blue
        } else {
            cell.celsiusAndFahrenheightLabel.textColor = UIColor.black
        }
        if weather.rainfallProbability > 50 {
            cell.rainfallProbabilityLabel.textColor = UIColor.orange
        } else {
            cell.rainfallProbabilityLabel.textColor = UIColor.black
        }
    }
}

//
//  CountryWeatherViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 12..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class CountryWeatherViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var tableView : UITableView!
    let defaultCellIdentifier : String = "cell"
    var weather : [WeatherInfo] = []
    var countries : CountryInfo!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.delegate = self
        tableView.dataSource = self
        self.navigationItem.title = countries.koreanName
        
        let jsonDecoder = JSONDecoder()
        guard let dataAsset : NSDataAsset = NSDataAsset(name: countries.assetName) else {
            return
        }
        do {
            self.weather = try jsonDecoder.decode([WeatherInfo].self, from: dataAsset.data)
        } catch {
            print (error.localizedDescription)
        }
        
        self.tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.weather.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: self.defaultCellIdentifier, for: indexPath)
        
        let weather : WeatherInfo = self.weather[indexPath.row]
        

        cell.textLabel?.text = weather.cityName
        cell.detailTextLabel?.numberOfLines = 0
        cell.detailTextLabel?.text = "섭씨 \(weather.state)도 /" + " 화씨 \(weather.fahrenheight)도" + "\n강수확률 \(weather.rainfallProbability)%"
        cell.imageView?.image = UIImage(named: weather.weatherImage)
        
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

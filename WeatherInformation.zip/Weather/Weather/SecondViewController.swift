//
//  SecondViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 8..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var textToSet : String?
    
    @IBOutlet var textLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.textLabel.text = self.textToSet
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

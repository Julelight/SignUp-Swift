//
//  ViewController.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 8..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView : UITableView?
    
    @IBAction func touchUpAddButton (_ sender:UIButton) {
        dates.append(Date())
        
//        performSegue(withIdentifier: "12", sender: Any?.self)
       // self.tableView?.reloadData()
        self.tableView?.reloadSections(IndexSet(2...2), with: UITableViewRowAnimation.automatic)
    }
    
    let dateFormatter: DateFormatter = {
        let formatter : DateFormatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    let timeFormatter: DateFormatter = {
        let formatter : DateFormatter = DateFormatter()
        formatter.timeStyle = .medium
        return formatter
    }()
    
    let cellIdentifier : String = "cell"
    let customCellIdentifier : String = "customCell"
    
    let korean : [String?] = ["가","나","다","라","마","바","사"]
    
    let english : [String?] = ["A","B","C","D","E","F","G"]
    
    var dates : [Date] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView?.delegate = self
        self.tableView?.dataSource = self
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0 : return korean.count
        case 1 : return english.count
        case 2 : return dates.count
        default : return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section < 2 {
            let cell : UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
            let text : String? = indexPath.section == 0 ? korean[indexPath.row] : english[indexPath.row]
            cell.textLabel?.text = text
            
            return cell
        } else {
            if let cell : CustomTableViewCell = tableView.dequeueReusableCell(withIdentifier: customCellIdentifier, for: indexPath) as? CustomTableViewCell {
                cell.leftLabel?.text = self.dateFormatter.string(from: self.dates[indexPath.row])
                cell.rightLabel?.text = self.timeFormatter.string(from: self.dates[indexPath.row])
                return cell
            } else {
                return UITableViewCell()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section < 2 {
            return section == 0 ? "한글" : "영어"
        }
        return nil
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let nextViewController : SecondViewController = segue.destination as? SecondViewController else {
            return
        }
        
        guard let cell : UITableViewCell = sender as? UITableViewCell else {
            return
        }
        nextViewController.textToSet = cell.textLabel?.text
        print("done")

    }
}


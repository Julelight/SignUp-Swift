//
//  Friend.swift
//  Weather
//
//  Created by cscoi009 on 2019. 8. 9..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import Foundation

struct Friend : Codable {
    
    struct Address : Codable {
        let country : String
        let city : String
    }
    
    let name : String
    let age : Int
    let addressInfo : Address
    
    var fullAddress : String {
        return self.addressInfo.country + " ," + self.addressInfo.city
    }
    
    var nameAndAge : String {
        return self.name + "(\(self.age))"
    }
    
    enum CodingKeys : String, CodingKey {
        case name, age
        case addressInfo = "address_info"
    }
    
}

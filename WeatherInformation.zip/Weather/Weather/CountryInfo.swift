
import Foundation

struct CountryInfo : Codable {

    // countries.json
    let koreanName : String
    let assetName : String
    
    var flagOfCountry : String {
        return "flag_" + self.assetName
    }
    
    enum CodingKeys : String, CodingKey {
        case koreanName = "korean_name"
        case assetName = "asset_name"
    }
}

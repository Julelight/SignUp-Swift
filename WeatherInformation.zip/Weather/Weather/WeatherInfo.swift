
import Foundation

struct WeatherInfo : Codable {
    
    // (fr,jp,us,kr...).json
    let cityName : String
    let state : Int
    let celsius : Double
    let rainfallProbability : Int

    var fahrenheight : Double {
        return celsius * 1.8 + 32
    }
    
    var weatherImage : String! {
        if state == 10 {
            return "rainy"
        } else if state == 11 {
            return "cloudy"
        } else if state == 12 {
            return "sunny"
        } else if state == 13 {
            return "snowy"
        }
        return "none"
    }

    
    enum CodingKeys : String, CodingKey {
        case cityName = "city_name"
        case state, celsius
        case rainfallProbability = "rainfall_probability"
    }
}

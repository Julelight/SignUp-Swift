//
//  SignUpViewController.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 6..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate {

    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var checkPasswordField : UITextField!
    @IBOutlet weak var selfIntroduceView : UITextView!
    @IBOutlet weak var nextButton : UIButton!
    
    @IBAction func pushNextButton (_ sender: UIButton) {
            UserInformation.shared.id = idField.text
            UserInformation.shared.password = passwordField.text
    }
    
    @IBAction func dissmissButton (_ Sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    // imagePicker
    
    lazy var imagePicker: UIImagePickerController = {
        let picker : UIImagePickerController = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        return picker
    } ()
    
    @IBOutlet weak var imageView : UIImageView!
    
    @IBAction func touchUpSelectImageButton (_ sender: UIButton) {
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let editedImage : UIImage =  info[UIImagePickerControllerEditedImage] as? UIImage {
            self.imageView.image = editedImage
        }
        
        
        self.dismiss(animated: true, completion: nil)
    }
    
    // Gesture Recognizer
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        nextButton.isEnabled = false
        
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
        tapGesture.delegate = self
        
        self.view.addGestureRecognizer(tapGesture)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if passwordField.text?.isEmpty != true && passwordField.text == checkPasswordField.text && idField.text?.isEmpty != true && selfIntroduceView.text.isEmpty != true && imageView.image != nil {
            nextButton.isEnabled = true
        }
        self.view.endEditing(true)
        return true
    }


}


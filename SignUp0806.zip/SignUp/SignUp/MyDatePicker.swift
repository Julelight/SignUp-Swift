//
//  MyDatePicker.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 5..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class MyDatePicker: UIViewController {

    @IBOutlet weak var datePicker : UIDatePicker!
    @IBOutlet weak var birthDateLabel : UILabel?
    @IBOutlet weak var phoneNumberField : UITextField?
    @IBOutlet weak var signUpButton : UIButton?
    
    let dateFormatter : DateFormatter = {
        let formatter: DateFormatter = DateFormatter()
        formatter.dateStyle = .medium
//        formatter.timeStyle = .medium
        return formatter
    }()
    
    @IBAction func didDataPickerValueChanged(_ sender:UIDatePicker?) {
        
        let date : Date =  self.datePicker.date
        let dateString : String = self.dateFormatter.string(from: date)
        
        self.birthDateLabel?.text? = dateString
        
        if phoneNumberField?.text?.isEmpty != true {
            signUpButton?.isEnabled = true
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        signUpButton?.isEnabled = false
        self.datePicker.addTarget(self, action: #selector(self.didDataPickerValueChanged(_:)), for: UIControlEvents.valueChanged)
        // Do any additional setup after loading the view.
    }

    @IBAction func popToPrev() {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func cancelSignUp() {
        UserInformation.shared.id = nil
        UserInformation.shared.password = nil
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func finishSignUp() {
        self.dismiss(animated: true, completion: nil)
    }
}

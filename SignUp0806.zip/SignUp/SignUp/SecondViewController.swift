//
//  SecondViewController.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 5..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var nameLabel : UILabel!
    @IBOutlet weak var ageLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print ("SecondViewController의 View가 메모리에 로드 됨")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print ("SecondViewController의 View가 화면에 보여질 예정")
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print ("SecondViewController의 View가 화면에 보여짐.")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print ("SecondViewController의 View가 사라질 예정")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print ("SecondViewController의 View가 사라짐")
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print ("SecondViewController의 view가 Subview를 레이아웃 하려 함")
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print ("SecondViewController의 view가 Subview를 레이아웃함")
    }

    
    @IBAction func dissmissModal()
    {
        self.dismiss(animated: true, completion: nil)
    }
}

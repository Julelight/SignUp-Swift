//
//  SecondSignUpViewController.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 8..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SecondSignUpViewController: UIViewController, UIGestureRecognizerDelegate {
    
    //@IBOutlets
    @IBOutlet weak var datePicker : UIDatePicker!
    @IBOutlet weak var birthDateLabel : UILabel?
    @IBOutlet weak var phoneNumberField : UITextField?
    @IBOutlet weak var signUpButton : UIButton?
    
    //@IBActions
    @IBAction func didDataPickerValueChanged(_ sender:UIDatePicker?) {
        let date : Date =  self.datePicker.date
        let dateString : String = self.dateFormatter.string(from: date)
        self.birthDateLabel?.text? = dateString
        
        checkFillAllNeeds()
    }
    @IBAction func didPhonNumberFieldTextChanged(_ sender:UITextField?) {
        checkFillAllNeeds()
    }
    @IBAction func popToPrev() {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func cancelSignUp() {
        reset()
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func finishSignUp() {
        confirm()
        self.dismiss(animated: true, completion: nil)
    }

    let dateFormatter : DateFormatter = {
        let formatter: DateFormatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        signUpButton?.isEnabled = false
        
        self.navigationController?.isNavigationBarHidden = true
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
        
        self.datePicker.addTarget(self, action: #selector(self.didDataPickerValueChanged(_:)), for: UIControlEvents.valueChanged)
        self.phoneNumberField?.addTarget(self, action: #selector(self.didPhonNumberFieldTextChanged(_:)), for: UIControlEvents.editingChanged)
    }
    
    func reset() {
        UserInformation.shared.id = nil
        UserInformation.shared.password = nil
        UserInformation.shared.profileImage = nil
    }
    
    func confirm() {
        self.birthDateLabel?.text = UserInformation.shared.birthDate
        self.phoneNumberField?.text = UserInformation.shared.phoneNumber
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    func checkFillAllNeeds() {
        if birthDateLabel?.text?.isEmpty != true && phoneNumberField?.text?.isEmpty != true {
            signUpButton?.isEnabled = true
        } else {
            signUpButton?.isEnabled = false
        }
    }
}

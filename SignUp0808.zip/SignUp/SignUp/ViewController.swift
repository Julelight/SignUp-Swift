//
//  ViewController.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 5..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {

    @IBOutlet weak var mainIdField: UITextField!
    @IBOutlet weak var mainProfileImage : UIImageView?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.mainIdField.text = UserInformation.shared.id
        
        if let profileImage : UIImage = UserInformation.shared.profileImage as? UIImage {
            self.mainProfileImage?.image = profileImage
        } else {
            self.mainProfileImage?.image = nil
        }
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        self.view.endEditing(true)
        return false
    }

}


//
//  UserInformation.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 5..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import Foundation

class UserInformation {
    
    static let shared : UserInformation = UserInformation()
    
    var id : String?
    var password : String?
    var profileImage : Any?
    var birthDate : String?
    var phoneNumber : String?
}

//
//  SignUpViewController.swift
//  SignUp
//
//  Created by cscoi009 on 2019. 8. 6..
//  Copyright © 2019년 hashtag. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate, UITextViewDelegate {

    //@IBOutlets
    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var checkPasswordField : UITextField!
    @IBOutlet weak var selfIntroduceView : UITextView!
    @IBOutlet weak var nextButton : UIButton!
    @IBOutlet weak var imageView : UIImageView!
    
    //@IBActions
    @IBAction func pushNextButton (_ sender: UIButton) {
        confirm()
    }
    @IBAction func dissmissButton (_ Sender: UIButton) {
        reset()
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func touchUpSelectImageButton (_ sender: UIButton) {
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    @IBAction func didTextfieldValueChanged (_ sender: UITextField) {
        checkFillAllNeeds()
    }
    
    // imagePicker
    lazy var imagePicker: UIImagePickerController = {
        let picker : UIImagePickerController = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        return picker
    } ()

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let editedImage : UIImage =  info[UIImagePickerControllerEditedImage] as? UIImage {
            self.imageView.image = editedImage
            checkFillAllNeeds()
        }
        
        
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Default Setting
        self.navigationController?.isNavigationBarHidden = true
        nextButton.isEnabled = false
        
        //Delegate
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer()
        tapGesture.delegate = self
        self.view.addGestureRecognizer(tapGesture)
        selfIntroduceView.delegate = self
        
        //Target-Action Design Pattern
        self.idField.addTarget(self, action: #selector(didTextfieldValueChanged(_:)), for: UIControlEvents.editingChanged)
        self.passwordField.addTarget(self, action: #selector(didTextfieldValueChanged(_:)), for: UIControlEvents.editingChanged)
        self.checkPasswordField.addTarget(self, action: #selector(didTextfieldValueChanged(_:)), for: UIControlEvents.editingChanged)
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        checkFillAllNeeds()
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func confirm() {
        UserInformation.shared.id = idField.text
        UserInformation.shared.password = passwordField.text
        UserInformation.shared.profileImage = self.imageView.image
    }
    func reset() {
        UserInformation.shared.id = nil
        UserInformation.shared.password = nil
        UserInformation.shared.profileImage = nil
    }
    
    func checkFillAllNeeds() {
        if passwordField.text?.isEmpty != true && passwordField.text == checkPasswordField.text && idField.text?.isEmpty != true && selfIntroduceView.text.isEmpty != true && imageView.image != nil {
            nextButton.isEnabled = true
        } else {
            nextButton.isEnabled = false
        }
    }

}

